import { OpenAI } from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY // Must be set in Lambda env vars
});

export async function handler(event) {
  try {
    const body = JSON.parse(event.body);
    const input = body.text;

    if (!input) {
      return {
        statusCode: 400,
        headers: corsHeaders(),
        body: JSON.stringify({ error: 'Missing "text" in request.' })
      };
    }

    const prompt = `You are a structured data formatter for a meal-planning website.

    Given a plain-text recipe, return a JSON file that matches this exact format used by meals.stellation.one. Do not add extra commentary or wrapping text. Output **only the JSON object**. Follow these strict rules:
    
    ---
    
    🎯 Required Top-Level Keys:
    - \`id\`: kebab-case slug (e.g. "butter-chicken")
    - \`title\`: human-readable title
    - \`day\`: leave blank
    - \`description\`: short summary of the meal
    - \`link\`: a URL pointing to the source (use "https://example.com/placeholder" if none is provided)
    - \`sections\`: array of structured blocks
        
    ---
    
    🧱 Sections (JSON array under "sections"):
    Each section must be an object with:
    - \`title\`: section heading (include emoji prefix)
    - \`type\`: one of: "categorized-ingredients", "steps", or "list"
    - \`items\`: content of that section (format depends on type)
    
    ---
    
    🍱 Ingredients Section:
    - \`title\`: "🛒 Quick Ingredient Checklist"
    - \`type\`: "categorized-ingredients"
    - \`items\`: object with 4 keys:
      - \`freezer\`: array of strings
      - \`refrigerator\`: array of strings
      - \`pantry\`: array of strings
      - \`other\`: array of strings
    
    Example:
    {
      "type": "categorized-ingredients",
      "items": {
        "freezer": [],
        "refrigerator": ["1 lb chicken breast"],
        "pantry": ["2 tsp salt", "1 cup rice"],
        "other": []
      }
    }
    
    ---
    
    👩‍🍳 Steps Section:
    - \`title\`: "👩‍🍳 Recipe"
    - \`type\`: "steps"
    - \`items\`: array of numbered instructions (as strings)
    
    ---
    
    🥗 Nutrition Section:
    - \`title\`: "🍽️ Estimated Nutrition (Per Serving)"
    - \`type\`: "list"
    - \`items\`: list of simple nutrition facts as strings (e.g., "Protein: ~30g")
    
    ---
    
    Now, convert this recipe into valid JSON for meals.stellation.one:
    
    ${input}
    `;
    
    const chatResponse = await openai.chat.completions.create({
      model: "gpt-4o",
      temperature: 0.3,
      messages: [
        {
          role: "system",
          content: "You are a helpful assistant that converts plain-text recipes into structured JSON files for a meal planning site."
        },
        {
          role: "user",
          content: prompt
        }
      ]
    });

    const resultText = chatResponse.choices[0].message.content.trim();

    // Extract and parse only the JSON block (in case it includes markdown or extra commentary)
    const jsonStart = resultText.indexOf('{');
    const jsonEnd = resultText.lastIndexOf('}');
    const parsedJSON = JSON.parse(resultText.slice(jsonStart, jsonEnd + 1));

    return {
      statusCode: 200,
      headers: corsHeaders(),
      body: JSON.stringify(parsedJSON)
    };

  } catch (err) {
    console.error("Lambda error:", err);
    return {
      statusCode: 500,
      headers: corsHeaders(),
      body: JSON.stringify({ error: 'Failed to generate recipe JSON.' })
    };
  }
}

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
}
